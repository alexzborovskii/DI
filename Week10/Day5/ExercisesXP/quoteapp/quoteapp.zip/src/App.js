import Quotes from './components/Quotes.js';
import './App.css';

function App() {
  return (

      <Quotes />

  );
}

export default App;
